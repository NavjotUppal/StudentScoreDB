### delete database if exists ###
DROP DATABASE IF EXISTS student_management;

### create a fresh database ###
CREATE DATABASE student_management;

### select the database just created ###
USE student_management;

### create a table ###
CREATE TABLE student_score ( 
            SUBJECT VARCHAR(32),
            SCORE FLOAT,
            PRIMARY KEY(SUBJECT)
            );
			
### insert records ###
INSERT INTO student_score
                  (SUBJECT,SCORE)
                  VALUES
                  ("ENGLISH",95),
                  ("MATH",98),
                  ("SCIENCE",89);

### show contents of the table ###
SELECT * FROM student_score;

###DELETE contents from the table ###
DELETE FROM student_score WHERE SUBJECT='MATH';				  